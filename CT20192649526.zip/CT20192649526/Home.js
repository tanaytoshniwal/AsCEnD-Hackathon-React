import React from 'react'

const Home = props => {
    return (
        <h6>This is Home Page</h6>
    )
}

export default Home
